///Se leen N n�meros enteros y se emite el mayor y la posici�n en la que ingres� por
///primera vez; el valor del �ltimo y del primer n�mero ingresado

Algoritmo TP5Ej16
	//Definicion de variables
	Definir N, i, posMayor, mayor, primero, lim Como Entero
	
	Escribir Sin Saltar "Ingrese la cantidad de numeros a ingresar: "
	Leer lim
	
	Para i <- 1 Hasta lim Con Paso 1 Hacer
		Escribir Sin Saltar "Ingrese el ", i, "� numero: "
		Leer N
		Si (i = 1) Entonces
			mayor <- N
			posMayor <- i
			primero <- N
		SiNo
			Si (N > mayor) Entonces
				mayor <- N
				posMayor <- i
			FinSi
		FinSi
		
	FinPara
	
	Escribir "Numero mayor: ", mayor
	Escribir "Posicion mayor: ", posMayor
	Escribir "Primer numero ingresado: ", primero
	Escribir "Ultimo numero ingresado: ", N
	
FinAlgoritmo
